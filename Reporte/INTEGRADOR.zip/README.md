# Archivo Template-manuscrito.tex

Este archivo contiene todo los detalles de como se debe de redactar el informe final del proyecto integrador de primer semestre. Los archivos __IEEEcsmag.cls__, __sfmath.sty__ y __upmath.sty__ sirven para renderizar la plantilla del archivo __Template-manuscrito.tex__.

La carpeta __latex-imagenes__ contiene las 2 imagenes utilizadas por el archivo __Template-manuscrito.tex__. Se recomienda poner todas las imagenes que se van a utilizar para el reporte final dentro de esta carpeta.

El resultado de compilar el archivo __Template-manuscrito.tex__ se puede apreciar en el archivo __Template-manuscrito.pdf__.
